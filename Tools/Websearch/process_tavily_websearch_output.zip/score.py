import json
import re

def score(search_results):
    "Output: answer, success, errors, sr_1, sr_2, sr_3, sr_4, sr_5, sr_6, sr_7, sr_8, sr_9, sr_10, sr_11, sr_12, sr_13, sr_14, sr_15, sr_16, sr_17, sr_18, sr_19, sr_20"
    answer = ''
    success = 0
    errors = ''
    sr_1,sr_2,sr_3,sr_4,sr_5,sr_6,sr_7,sr_8,sr_9,sr_10,sr_11,sr_12,sr_13,sr_14,sr_15,sr_16,sr_17,sr_18,sr_19,sr_20 = [''] * 20
    
    try:
        # Handle empty string or None input
        if not search_results:
            errors += "Empty search results input\n"
        else:
            parsed = json.loads(search_results)
            answer = parsed.get('answer', '')
            results = parsed.get("results", [])

            # Limit to 20 results and warn if truncated
            if len(results) > 20:
                errors += f"Results truncated from {len(results)} to 20\n"
                results = results[:20]

            results = [json.dumps(r) for r in results]
            remainder = 20 - len(results)
            results += ['']*remainder
            
            # Ensure we have exactly 20 elements before unpacking
            if len(results) != 20:
                errors += f"Unexpected results length: {len(results)}\n"
                results = (results + [''] * 20)[:20]
                
            sr_1, sr_2, sr_3, sr_4, sr_5, sr_6, sr_7, sr_8, sr_9, sr_10, \
            sr_11, sr_12, sr_13, sr_14, sr_15, sr_16, sr_17, sr_18, sr_19, sr_20 = results
            success = 1
        
    except json.JSONDecodeError as e:
        errors += f"Invalid JSON format - {e}\n"
    except TypeError as e:
        errors += f"Invalid input type - {e}\n"
    except Exception as e:
        errors += f"Unexpected error - {e}\n"
        
    return answer, success, errors, sr_1, sr_2, sr_3, sr_4, sr_5, sr_6, sr_7, sr_8, sr_9, sr_10, sr_11, sr_12, sr_13, sr_14, sr_15, sr_16, sr_17, sr_18, sr_19, sr_20