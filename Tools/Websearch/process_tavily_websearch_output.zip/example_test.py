import os
import os.path
import sys

sys.path.append('/models/resources/viya/e203acdb-2e73-4c5a-91f2-d9ee1f42584f/')

import score

import settings_e203acdb_2e73_4c5a_91f2_d9ee1f42584f

settings_e203acdb_2e73_4c5a_91f2_d9ee1f42584f.pickle_path = '/models/resources/viya/e203acdb-2e73-4c5a-91f2-d9ee1f42584f/'

def score_record(search_results):
    "Output: answer,success,errors,sr_1,sr_2,sr_3,sr_4,sr_5,sr_6,sr_7,sr_8,sr_9,sr_10,sr_11,sr_12,sr_13,sr_14,sr_15,sr_16,sr_17,sr_18,sr_19,sr_20"
    return score.score(search_results)

print(score_record(""))
