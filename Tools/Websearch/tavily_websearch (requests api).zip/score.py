import ast
import json
from tavily import TavilyClient

def score(api_key, query, topic, search_depth, max_results, days, time_range, include_answer, include_raw_content, include_domains, exclude_domains, threshold):
    "Output: success, search_results, errors"

    def filter_by_score(search_results, threshold):
        if not search_results or "results" not in search_results:
            return search_results

        filtered_results = [
            result for result in search_results["results"]
            if result.get("score", 0) >= threshold
        ]

        # Return a copy with filtered results
        return {**search_results, "results": filtered_results}
    
    errors = ""

    include_answer = False if include_answer == 0 else True
    include_raw_content = False if include_raw_content == 0 else "markdown"

    # Validate search_depth
    if search_depth not in ("basic", "advanced"):
        errors += f"Invalid search_depth '{search_depth}' - defaulted to 'basic'.\n"
        search_depth = "basic"

    # Validate topic
    if topic not in ("general", "news"):
        errors += f"Invalid topic '{topic}' - defaulted to 'general'.\n"
        topic = "general"

    # Validate max_results
    if not (1 <= max_results <= 20):
        errors += f"Invalid max_results '{max_results}' - defaulted to 10.\n"
        max_results = 10

    # Validate time_range
    valid_ranges = {"day", "week", "month", "year", "d", "w", "m", "y"}
    if time_range not in valid_ranges:
        errors += f"Invalid time_range '{time_range}' - defaulted to None.\n"
        time_range = None
    
    if topic == 'news':
        time_range = None

    # Validate days
    if days < 1:
        errors += f"Invalid days '{days}' - defaulted to 1.\n"
        days = 7

    # Parse include_domains
    try:
        include_domains = ast.literal_eval(include_domains) if isinstance(include_domains, str) else include_domains
        if not isinstance(include_domains, list):
            raise ValueError()
    except Exception:
        errors += "Failed to parse include_domains - defaulted to empty list.\n"
        include_domains = []

    # Parse exclude_domains
    try:
        exclude_domains = ast.literal_eval(exclude_domains) if isinstance(exclude_domains, str) else exclude_domains
        if not isinstance(exclude_domains, list):
            raise ValueError()
    except Exception:
        errors += "Failed to parse exclude_domains - defaulted to empty list.\n"
        exclude_domains = []

    # Parse search threshold
    if not (isinstance(threshold, (float, int)) and 0 <= float(threshold) <= 1):
        errors += f"Invalid threshold '{threshold}' - defaulted to 0.5.\n"
        threshold = 0.5
    else:
        threshold = float(threshold)

    # Execute the search
    try:
        tavily_client = TavilyClient(api_key=api_key)
        response = tavily_client.search(
            query=query,
            topic=topic,
            search_depth=search_depth,
            max_results=max_results,
            time_range=time_range,
            days=days,
            include_answer=include_answer,
            include_raw_content=include_raw_content,
            include_domains=include_domains,
            exclude_domains=exclude_domains
        )
        success = 1
        search_results = filter_by_score(response, threshold=threshold)
        search_results = json.dumps(search_results)

    except Exception as e:
        success = 0
        search_results = ""
        errors += f"Tavily client search failed: {e}\n"

    return success, search_results, errors