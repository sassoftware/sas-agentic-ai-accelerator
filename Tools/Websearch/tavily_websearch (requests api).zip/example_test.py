import os
import os.path
import sys

sys.path.append('/models/resources/viya/89c21445-61e9-4ab4-a849-56c4273155d5/')

import score

import settings_89c21445_61e9_4ab4_a849_56c4273155d5

settings_89c21445_61e9_4ab4_a849_56c4273155d5.pickle_path = '/models/resources/viya/89c21445-61e9-4ab4-a849-56c4273155d5/'

def score_record(api_key,query,topic,search_depth,max_results,days,time_range,include_answer,include_raw_content,include_domains,exclude_domains,threshold):
    "Output: success,search_results,errors"
    return score.score(api_key,query,topic,search_depth,max_results,days,time_range,include_answer,include_raw_content,include_domains,exclude_domains,threshold)

print(score_record("","","","",106,5,"",181,18,"","",60.60))
